package com.example.restApi;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
	@GetMapping("/AllDetails")
	public ArrayList<Product> productDetails() {
		ArrayList<Product> al=new ArrayList<Product>();
		al.add(new Product(1,"Laptop","Dell 5245","Electronics","50K"));
		al.add(new Product(2,"Mobile","I Phone 11","Electronics","70K"));
		al.add(new Product(3,"T-Shirt","PeterEngland","Clothing","4K"));
		al.add(new Product(1,"Jeans"," Roadster","Clothing","3K"));



		return al;
		
	}
	
	


      
		
		
	}


